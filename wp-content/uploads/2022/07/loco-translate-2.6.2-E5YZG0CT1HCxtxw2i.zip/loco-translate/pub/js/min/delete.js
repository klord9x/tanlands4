!function(o, e) {
var n = e.getElementById("loco-fs"), t = e.getElementById("loco-del");
n && t && o.loco.fs.init(n).setForm(t);
}(window, document, window.jQuery);