<?php
/**
 * PO file editor
 */
$this->extend('editor');
$this->start('header');

echo $this->render('../common/inc-po-header');
